﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace InterfazTP
{
    public class Banco
    {
        public List<Usuario> usuario { get; set; }
        private List<CajaDeAhorro> caja { get; set; }
        private List<PlazoFijo> pfs { get; set; }
        private List<TarjetaDeCredito> tarjetas { get; set; }
        private List<Pago> pagos { get; set; }
        private List<Movimiento> movimientos { get; set; }
        public Usuario usuarioActual { get; set; }
        public int cbu = 1000;

        public Banco()
        {
            pagos = new List<Pago>();
            tarjetas = new List<TarjetaDeCredito>();
            movimientos = new List<Movimiento>();
            pfs = new List<PlazoFijo>();
            caja = new List<CajaDeAhorro>();
            usuario = new List<Usuario>();
        }

        public bool AltaUsuario(string user, string password, string nombre, string apellido, string dni, string email)
        {
            if (password.Length < 8 || user.Length < 8)
            {
                MessageBox.Show("Usuario y Contraseña deben tener minimo 8 caracteres.");
                return false;
            }
            else
            {
                Usuario nuevoUsuario = new Usuario();
                nuevoUsuario.usuarioLogin = user;
                nuevoUsuario.password = password;
                nuevoUsuario.nombre = nombre;
                nuevoUsuario.apellido = apellido;
                nuevoUsuario.dni = dni;
                nuevoUsuario.email = email;

                usuario.Add(nuevoUsuario);
                return true;
            }
        }

        public bool ModificarUsuario(string user, string password, string nombre, string apellido, string dni, string email)
        {
            bool result = false;

            foreach (var usuario in usuario)
            {
                if (usuario.usuarioLogin == usuarioActual.usuarioLogin)
                {

                    if (nombre == "" || apellido == "" || dni == "" || email == "")
                    {
                        result = false;
                    }
                    else
                    {
                        if (user.Length < 8 || password.Length < 8)
                        {
                            MessageBox.Show("Usuario y contraseña deben tener minimo 8 caracteres.");
                            result = false;
                        }
                        else
                        {
                            usuario.nombre = nombre;
                            usuario.apellido = apellido;
                            usuario.email = email;
                            usuario.usuarioLogin = user;
                            usuario.password = password;

                            result = true;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("No registrado");
                    result = false;
                }
            }
            return result;
        }

        public void AltaCajaAhorro(Usuario usuarioActual)
        {

            if (usuarioActual != null)
            {
                // Usuario
                CajaDeAhorro nuevaCajaAhorro = new CajaDeAhorro();
                nuevaCajaAhorro.saldo = 0;
                nuevaCajaAhorro.cbu = cbu;
                nuevaCajaAhorro.titular.Add(usuarioActual);
                usuarioActual.cajas.Add(nuevaCajaAhorro);


                // Banco
                caja.Add(nuevaCajaAhorro);
                cbu++;

            }

        }

        public void BajaCajaAhorro(int id)
        {
            if (usuarioActual != null)
            {
                foreach (var c in usuarioActual.cajas)
                {
                    if (c.id == id)
                    {
                        if (c.saldo == 0)
                        {
                            usuarioActual.cajas.Remove(c);
                            caja.Remove(c);
                        }
                        else
                        {
                            Console.WriteLine("La caja no se puede eliminar si cuenta con saldo.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No tiene cajas de ahorro asociadas.");
                    }
                }
            }
            else
            {
                Console.WriteLine("No tiene cajas de ahorro.");
            }

        }

        public void ModificarCajaAhorro(int id)
        {
            foreach (var c in usuarioActual.cajas)
            {
                if (c.id == id)
                {
                    c.id = 0;
                    c.cbu = 0;
                }
                else
                {
                    Console.WriteLine("No tiene caja ahorro!");
                }
            }
        }

        public bool IniciarSesion(string usuario, string contraseña)
        {
            bool encontre = false;
            
            foreach (Usuario usuarioInd in this.usuario)
            {
                

                if (usuarioInd.usuarioLogin == usuario && usuarioInd.password == contraseña)
                {
                    encontre = true;
                    usuarioActual = usuarioInd;
                }
                
            }
            return encontre;
        }
    }
}